package br.senai.sp.escolamvc.repository;

import br.senai.sp.escolamvc.model.Endereco;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EnderecoRepository extends JpaRepository<Endereco, Long> {
}
