package br.senai.sp.escolamvc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class
EscolamvcApplication {

	public static void main(String[] args) {
		SpringApplication.run(EscolamvcApplication.class, args);
	}

}
